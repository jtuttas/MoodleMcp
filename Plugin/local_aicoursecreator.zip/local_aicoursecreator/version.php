<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_aicoursecreator';
$plugin->version   = 2025041913;  // Format: YYYYMMDDNN – NN bei mehreren Releases pro Tag hochzählen
$plugin->requires  = 2022041900;  // Moodle 4.0+
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '1.0.13';

// Changelog:
// 1.0.13 (2025041913) – Fix (eigentliche Ursache): set_field auf die nicht existierenden
//                        assign-Spalten introattachments/introattachmentsonsubmission entfernt
//                        bzw. mit get_columns()-Guard abgesichert. Diese Writes warfen die
//                        dml_write_exception. Upload liefert jetzt sauber {fileid,message}.
// 1.0.12 (2025041912) – rebuild_course_cache() entfernt (war NICHT die Ursache, aber ebenfalls
//                        ein potenzieller Transaktions-Vergifter).
// 1.0.11 (2025041911) – Erneuter Versions-Bump: registriert upload_assignfile in external_functions
//                        (OPcache hält beim vorherigen Upgrade noch die alte services.php)
// 1.0.10 (2025041910) – Versions-Bump erzwingt Neuregistrierung der Web-Service-Funktionen
// 1.0.2 (2025041902) – Bugfix: course_modules hat kein timemodified-Feld
// 1.0.1 (2025041901) – Bugfixes:
//   - modlib.php require_once ergänzt (add_moduleinfo war nicht gefunden)
//   - markingworkflow + markingallocation in create_assign ergänzt
//   - update_* Funktionen: !== '' statt if() + timemodified immer setzen
//   - create_url + create_label als neue Funktionen
// 1.0.0 (2025041800) – Erstveröffentlichung
